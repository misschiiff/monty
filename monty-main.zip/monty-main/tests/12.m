push 1
push 2
push 3
push 4
push 0
push 110
push 00
push 110
push 111
push 116
push 114
push 101
push 98
push 108
push 111
push 72
pstr
