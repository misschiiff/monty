push 0
push 1
push 2
      push 3
                  pall           
  push 4
    push 5   
      push    6      
pall





push 7
pall


